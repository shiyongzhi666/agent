import configparser
import json
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Dict, Optional
from urllib.parse import parse_qs, urlparse

import requests


class SeatReserver:
    """End-to-end helper for logging in and reserving a seat."""

    AREA_MAP = {
        "A": {"label": "七星灯火A区", "site_no": "qxdh_b", "start": 1, "end": 130},
        "B": {"label": "七星灯火B区", "site_no": "qxdh", "start": 131, "end": 213},
    }

    def __init__(self, config_path: str = "seat_reserver.ini") -> None:
        self.config_path = Path(config_path)
        if not self.config_path.exists():
            raise FileNotFoundError(f"Config file not found: {self.config_path}")

        self.config = configparser.ConfigParser()
        self.config.read(self.config_path, encoding="utf-8")

        self.session = requests.Session()
        ua = self.config.get("http", "user_agent", fallback="Mozilla/5.0")
        self.session.headers.update({"User-Agent": ua})

        self.login_code: Optional[str] = None
        self.api_token: Optional[str] = None

    # ------------------------------------------------------------------ #
    # High-level workflow
    # ------------------------------------------------------------------ #
    def run(self) -> Dict[str, Any]:
        self._login()
        self._exchange_token()
        seat_info = self._fetch_seat_status()
        payload = self._build_order_payload(seat_info)
        order_result = self._post_order(payload)

        # Merge seat info into the result so the agent knows what was booked
        return {
            "order_result": order_result,
            "seat_info": {
                "area": self._get_area_label(seat_info.get("siteNo")),
                "seat_no": seat_info.get("seatNo"),
                "site_no": seat_info.get("siteNo"),
            }
        }

    def _get_area_label(self, site_no: str) -> str:
        if not site_no:
            return "Unknown"
        for meta in self.AREA_MAP.values():
            if meta["site_no"] == site_no:
                return meta["label"]
        return site_no

    def configure_user(self, username: str, password: str, target_area: Optional[str] = None, target_seat_no: Optional[int] = None) -> None:
        self.config.setdefault("auth", {})
        self.config.setdefault("api", {})
        self.config["auth"]["username"] = username
        self.config["auth"]["password"] = password
        self.config["api"]["target_area"] = target_area or ""
        self.config["api"]["target_seat_no"] = str(target_seat_no) if target_seat_no else ""
        # clear explicit overrides unless user config supplies them
        self.config["api"]["site_no"] = self.config["api"].get("site_no", "")
        self.config["api"]["seat_no"] = self.config["api"].get("seat_no", "")

    # ------------------------------------------------------------------ #
    # Authentication
    # ------------------------------------------------------------------ #
    def _login(self) -> None:
        auth_cfg = self.config["auth"]
        login_url = auth_cfg["login_url"]
        username = auth_cfg["username"]
        password = auth_cfg["password"]

        form = {
            "username": username,
            "password": password,
        }

        headers = {
            "Content-Type": "application/x-www-form-urlencoded",
            "Origin": auth_cfg.get("origin", login_url.split("/user_api", 1)[0]),
            "Referer": auth_cfg.get("referer", auth_cfg.get("origin", "")),
            "User-Agent": self.config.get("http", "user_agent", fallback="Mozilla/5.0"),
        }

        cookies: Dict[str, str] = {}
        union_query = auth_cfg.get("union_query_cookie", "").strip()
        if union_query:
            cookies["Union-Query"] = union_query

        resp = self.session.post(login_url, data=form, headers=headers, cookies=cookies or None, timeout=10)
        resp.raise_for_status()

        data = resp.json()

        access_token = data.get("access_token") or data.get("data", {}).get("access_token")
        if not access_token:
            raise RuntimeError("Could not find access_token in login response.")
        self.api_token = access_token


        # 进一步验证得到 code
        auth_url = "https://user.lib.tju.edu.cn/user_api/v1/member/authorize"
        auth_payload = {
            "response_type": "authorization_code",
            "client_id": "uni10x18ee170557b",
            "redirect_uri": "https://zw.lib.tju.edu.cn/dd-api/auth/redirect-uri",
            "scope": "",
            "state": ""
        }
        # headers 中 origin 和 referer 同上
        verify_headers = {
            "Content-Type": "application/json",
            "Origin": headers["Origin"],
            "Referer": headers["Referer"],
            "User-Agent": headers["User-Agent"],
            "Authorization": f"Bearer {self.api_token}",
        }
        resp_verify = self.session.post(auth_url, json=auth_payload, headers=verify_headers, timeout=10)
        resp_verify.raise_for_status()
        verify_data = resp_verify.json()
        # 若 verify_data 中有 code 字段，可以覆盖 self.login_code
        verify_code = verify_data.get("code") or verify_data.get("data", {}).get("code")
        if verify_code:
            self.login_code = verify_code

    def _exchange_token(self) -> None:
        if not self.login_code:
            raise RuntimeError("Call _login() before exchanging token.")

        redirect_cfg = self.config["redirect"]
        redirect_url = redirect_cfg["redirect_url"]

        resp = self.session.get(
            redirect_url,
            params={"code": self.login_code},
            allow_redirects=False,
            timeout=10,
        )
        resp.raise_for_status()

        location = resp.headers.get("Location")
        if not location:
            raise RuntimeError("Redirect response missing Location header.")

        # token is stored in fragment: https://.../#/pages/auth?token=xxx
        fragment = urlparse(location).fragment or ""
        token = self._extract_query_value(f"dummy://host/?{fragment.split('?', 1)[-1]}", "token")
        if not token:
            raise RuntimeError("API token missing in redirect fragment.")

        self.api_token = token
    # ------------------------------------------------------------------ #
    # Seat discovery & reservation
    # ------------------------------------------------------------------ #
    def _fetch_seat_status(self) -> Dict[str, Any]:
        api_cfg = self.config["api"]
        explicit_site = api_cfg.get("site_no", fallback="").strip()
        explicit_seat = api_cfg.get("seat_no", fallback="").strip()
        target_area_name = api_cfg.get("target_area", fallback="").strip()
        target_seat_no = api_cfg.get("target_seat_no", fallback="").strip()

        if explicit_site and explicit_seat:
            seat = self._query_single_seat(explicit_site, int(explicit_seat))
            if seat.get("state") != "leisure":
                raise RuntimeError("指定座位当前不可用。")
            return seat

        resolved_area = self._resolve_area(target_area_name)
        if resolved_area and target_seat_no:
            meta = self.AREA_MAP[resolved_area]
            seat_number = int(target_seat_no)
            if not (meta["start"] <= seat_number <= meta["end"]):
                raise RuntimeError("目标座位号超出区域范围。")
            seat = self._query_single_seat(meta["site_no"], seat_number)
            if seat.get("state") != "leisure":
                raise RuntimeError("指定区域的座位当前不可用。")
            return seat

        search_order = (
            [resolved_area] if resolved_area else list(self.AREA_MAP.keys())
        )

        last_error_msg = "未找到空闲座位"

        for area_key in search_order:
            meta = self.AREA_MAP[area_key]
            print(f"Searching area {area_key}...") # Optional: debug log

            area_failed = False
            for seat_no in range(meta["start"], meta["end"] + 1):
                if area_failed:
                    break

                try:
                    seat = self._query_single_seat(meta["site_no"], seat_no)

                    # Check for API-level errors returned in JSON (even if HTTP 200)
                    # Example: {'code': 400, 'msg': '区域七星灯火A区未进入开放时间'}
                    if seat.get("code") and str(seat.get("code")) != "200":
                         msg = seat.get("msg", "Unknown Error")
                         if "未进入开放时间" in msg or "闭馆" in msg:
                             print(f"Area {area_key} is closed: {msg}")
                             last_error_msg = msg
                             area_failed = True # Skip rest of this area
                             break

                    if seat.get("state") == "leisure":
                        return seat

                except Exception as e:
                    # Handle network/HTTP errors
                    err_msg = str(e)
                    if "未进入开放时间" in err_msg:
                        print(f"Area {area_key} unavailable: {err_msg}")
                        last_error_msg = err_msg
                        area_failed = True
                        break
                    continue

        raise RuntimeError(f"预约失败：{last_error_msg}")

    def _query_single_seat(self, site_no: str, seat_no: int) -> Dict[str, Any]:
        api_cfg = self.config["api"]
        status_url = api_cfg["seat_status_url"]
        params_raw = api_cfg.get("seat_status_params")
        base_params = json.loads(params_raw) if params_raw else {}
        params = {**base_params, "siteNo": site_no, "seatNo": seat_no}

        resp = self.session.get(
            status_url,
            headers=self._auth_headers(),
            params=params,
            timeout=10,
        )
        resp.raise_for_status()
        result = resp.json()
        seat_data = result.get("data", result)
        seat_data.setdefault("siteNo", site_no)
        seat_data.setdefault("seatNo", seat_no)
        return seat_data

    def _build_order_payload(self, seat_info: Dict[str, Any]) -> Dict[str, Any]:
        """Pick the target seat information and shape the POST body."""
        if not seat_info or not seat_info.get("cardNo"):
            raise RuntimeError("缺少座位 cardNo，无法生成预约参数。")

        api_cfg = self.config["api"]
        utc_ms = int(datetime.now(timezone.utc).timestamp() * 1000)
        # # 获取北京时间当天17:00之后（即下午五点）的UTC毫秒时间戳
        # from datetime import timedelta

        # beijing_now = datetime.now(timezone.utc) + timedelta(hours=8)
        # if beijing_now.hour < 17:
        #     # 还没到17点，取今天的17点
        #     target_beijing = beijing_now.replace(hour=18, minute=0, second=0, microsecond=0)
        # else:
        #     # 已经过了17点，取明天的17点
        #     target_beijing = (beijing_now + timedelta(days=1)).replace(hour=18, minute=0, second=0, microsecond=0)
        # # 转换为UTC
        # target_utc = target_beijing - timedelta(hours=8)
        # utc_ms = int(target_utc.timestamp() * 1000)
        # print(utc_ms)

        payload = {
            "cardNo": seat_info["cardNo"],
            "costPoints": api_cfg.getint("cost_points", fallback=0),
            "defaultPreOrderMinutes": api_cfg.getint("default_minutes", fallback=30),
            "preOrderMinutes": api_cfg.getint("preorder_minutes", fallback=30),
            "t": utc_ms,
        }

        return payload

    def _post_order(self, payload: Dict[str, Any]) -> Dict[str, Any]:
        api_cfg = self.config["api"]
        order_url = api_cfg["order_url"]

        headers = self._auth_headers()
        headers["Content-Type"] = "application/json; charset=UTF-8"

        resp = self.session.post(order_url, json=payload, headers=headers, timeout=10)
        resp.raise_for_status()
        result = resp.json()

        # Check business logic success
        # Adjust logic based on actual API response structure (e.g. code or success field)
        if str(result.get("code")) != "200":
            msg = result.get("msg") or result.get("message") or "Unknown error"
            raise RuntimeError(f"预约下单失败: {msg} (Code: {result.get('code')})")

        return result

    # ------------------------------------------------------------------ #
    # Helpers
    # ------------------------------------------------------------------ #
    @staticmethod
    def _extract_query_value(url: str, key: str) -> Optional[str]:
        parsed = urlparse(url)
        query = parsed.query or parsed.fragment
        params = parse_qs(query)
        values = params.get(key)
        return values[0] if values else None

    def _auth_headers(self) -> Dict[str, str]:
        headers: Dict[str, str] = {}
        if self.api_token:
            headers["Authorization"] = f"Bearer {self.api_token}"
        origin = self.config.get("http", "origin", fallback=None)
        referer = self.config.get("http", "referer", fallback=None)
        if origin:
            headers["Origin"] = origin
        if referer:
            headers["Referer"] = referer
        return headers

    def _resolve_area(self, value: str) -> Optional[str]:
        if not value:
            return None
        normalized = value.strip().upper()
        for key, meta in self.AREA_MAP.items():
            if normalized in {key, meta["label"].upper()}:
                return key
        return None


def reserve_seat(
    username: str,
    password: str,
    target_area: Optional[str] = None,
    target_seat_no: Optional[int] = None,
    config_path: str = "seat_reserver.ini",
) -> Dict[str, Any]:
    reserver = SeatReserver(config_path=config_path)
    reserver.configure_user(username, password, target_area, target_seat_no)
    return reserver.run()


if __name__ == "__main__":
    raise SystemExit(
        "This module exposes reserve_seat(). Call it from another script (see reserve_cli.py)."
    )
